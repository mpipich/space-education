create
    definer = root@`%` function get_region(region varchar(255), area varchar(255)) returns varchar(255)
BEGIN
    IF (IFNULL(region, '') = '') THEN 
      BEGIN
        RETURN IFNULL(area, '');
      END;
      ELSE
      BEGIN
        RETURN region;
      END;
    END IF;
  END;

