create
    definer = root@`%` function lcfirst(c varchar(255)) returns varchar(255)
BEGIN
    RETURN concat(upper(LEFT (LOWER(c), 1)), substr(LOWER(c), 2));
  END;

