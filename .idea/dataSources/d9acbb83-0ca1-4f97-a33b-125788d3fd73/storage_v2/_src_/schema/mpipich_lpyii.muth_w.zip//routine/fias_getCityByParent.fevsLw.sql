create
    definer = root@`%` procedure fias_getCityByParent(IN parentGuid varchar(255), IN REGION int, OUT ID varchar(255))
Begin 

  DECLARE pAOGUID, pAOLEVEL, pPARENTGUID, pSHORTNAME, pOFFNAME varchar(255);
  SELECT a.AOGUID, a.AOLEVEL, a.PARENTGUID, a.SHORTNAME, a.OFFNAME INTO pAOGUID, pAOLEVEL, pPARENTGUID, pSHORTNAME, pOFFNAME
  FROM addrobjectpar a WHERE AOGUID = parentGuid AND a.LIVESTATUS = 1 AND a.REGIONCODE = REGION;
  IF(pAOLEVEL IN (4,6)) THEN 
  BEGIN  
    SET ID = pAOGUID;
  END; 
    ELSE 
    BEGIN
      IF(pOFFNAME IN ('Москва', 'Санкт-Петербург', 'Севастополь')) THEN 
      BEGIN
         SET ID = pAOGUID;
      END;
      ELSE
        BEGIN
          IF(IFNULL(pPARENTGUID,'') = '') THEN 
          BEGIN SET ID=NULL; 
          END; 
          ELSE 
          BEGIN 
            call fias_getCityByParent(pPARENTGUID,REGION, ID);
          END;
          END IF;
        END;
      END IF;
    END;
  END IF;
END;

