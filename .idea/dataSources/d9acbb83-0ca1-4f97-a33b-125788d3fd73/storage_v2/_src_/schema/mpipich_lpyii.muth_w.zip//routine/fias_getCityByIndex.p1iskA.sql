create
    definer = root@`%` procedure fias_getCityByIndex(IN POSTALCODE int, IN REGION int)
BEGIN 
  DECLARE CUR_AOGUID, CUR_AOLEVEL, CUR_FORMALNAME, CUR_OFFNAME, CUR_PARENTGUID, CUR_SHORTNAME varchar(255);
  DECLARE CUR_LIVESTATUS int;
  DECLARE PAR_AOGUID, PAR_AOLEVEL, PAR_FORMALNAME, PAR_OFFNAME, PAR_PARENTGUID, PAR_SHORTNAME varchar(255);
  DECLARE Cid int;
  DECLARE CNAME, SCNAME varchar(255);
  DECLARE RET int DEFAULT 0;
  DECLARE PARENT, PPP varchar(255);
  DECLARE id_update integer DEFAULT UNIX_TIMESTAMP(); 
  /* переменная hadler - a*/
  DECLARE done integer default 0;
  /* Объявление курсора*/
  DECLARE BankCursor Cursor for 
  /* Селект на выборку данных которые расходятся со справочником почты России */
  SELECT a.AOGUID, a.AOLEVEL, a.FORMALNAME, a.OFFNAME, a.PARENTGUID, a.SHORTNAME, a.LIVESTATUS  FROM addrobjectpar a IGNORE INDEX(IDX_addrobjectpar_REGIONCODE, IDX_addrobjectpar)
  WHERE a.REGIONCODE = REGION 
  AND a.POSTALCODE = POSTALCODE 
  -- AND a.LIVESTATUS = 1 
  ORDER BY a.AOLEVEL;

  DECLARE Parents Cursor FOR
    SELECT a.PARENTGUID FROM addrobjectpar a 
    WHERE a.POSTALCODE = POSTALCODE 
    AND a.REGIONCODE = REGION 
    AND a.AOLEVEL NOT IN (6,4) 
    AND a.LIVESTATUS = 1  
    GROUP BY a.PARENTGUID;
  
  SELECT c.id, c.name, s.scname INTO Cid, CNAME, SCNAME FROM cities c 
  INNER JOIN operationaddress o ON c.id = o.cityId 
  LEFT JOIN socrbase s ON c.kodtst = s.kod_t_st
  WHERE o.`index` = POSTALCODE;

  Open BankCursor;
    BEGIN
    /*HANDLER назначение, которого поясним чуть ниже*/
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
    /* извлекаем данные */
    WHILE done = 0 DO 
      FETCH BankCursor INTO CUR_AOGUID,CUR_AOLEVEL,CUR_FORMALNAME,CUR_OFFNAME,CUR_PARENTGUID, CUR_SHORTNAME, CUR_LIVESTATUS;
        SET max_sp_recursion_depth=255;
        IF((CUR_AOLEVEL = 4 OR CUR_AOLEVEL = 6)) THEN
          BEGIN
            IF((compare_city(CUR_OFFNAME,CNAME) != 0)) THEN
              BEGIN
                set RET = 1;
                UPDATE cities c1 set AOGUID = CUR_AOGUID WHERE c1.id = Cid;
                -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES (4 ,POSTALCODE , 1 ,CONCAT(IFNULL(POSTALCODE,'NULL'), ' Найден!'));
                IF(SCNAME != CUR_SHORTNAME) THEN 
                  BEGIN
                    INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) 
                    VALUES (4 ,POSTALCODE , 2 ,CONCAT('Обновление типа населеннго пункта ',IFNULL(CNAME,'NULL'), ' c: ', IFNULL(SCNAME,'NULL'), ' на ', IFNULL(CUR_SHORTNAME,'NULL'), ' Индекс: ', POSTALCODE));
                    UPDATE cities c set c.kodtst = (SELECT s.kod_t_st FROM socrbase s WHERE s.scname = CUR_SHORTNAME AND s.level = CUR_AOLEVEL) WHERE c.id = Cid;
                    set RET = 1;
                  END;
                END IF;
                IF(CUR_LIVESTATUS = 1) THEN set done = 1; END IF;
              END;
            END IF;
          END;
        END IF;
      END WHILE;
    END;
    /*закрытие курсора */
  Close BankCursor;
  
  IF(RET != 1) THEN 
    BEGIN 
      SET done = 0;
      Open Parents;
        BEGIN
          /*HANDLER назначение, которого поясним чуть ниже*/
          DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
          WHILE done = 0 DO 
            FETCH Parents INTO PPP;
            -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log )  VALUES (4 ,POSTALCODE , 3 ,CONCAT(IFNULL(CUR_OFFNAME,'NULL'), ' != ', IFNULL(CNAME,'NULL')));
              CALL fias_getCityByParent(PPP,REGION,PARENT);
              SELECT a.AOGUID, a.AOLEVEL, a.FORMALNAME, a.OFFNAME, a.PARENTGUID, a.SHORTNAME  
              INTO PAR_AOGUID, PAR_AOLEVEL, PAR_FORMALNAME, PAR_OFFNAME, PAR_PARENTGUID, PAR_SHORTNAME
              FROM addrobjectpar a IGNORE INDEX(IDX_addrobjectpar_REGIONCODE, IDX_addrobjectpar)
              WHERE a.REGIONCODE = REGION 
                AND a.AOGUID = PARENT
              ORDER BY a.AOLEVEL, a.LIVESTATUS DESC LIMIT 1;
      
              IF((compare_city(PAR_OFFNAME, CNAME) != 0)) THEN 
                BEGIN
                  set done = 2;
                  -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES (4 ,POSTALCODE , 4 ,CONCAT(POSTALCODE, ' Найден!'));
                  UPDATE cities c1 set AOGUID = PAR_AOGUID WHERE c1.id = Cid;
                  IF(SCNAME != PAR_SHORTNAME) THEN 
                    BEGIN
                      INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) 
                      VALUES (4 ,POSTALCODE , 5 ,CONCAT('Обновление типа населеннго пункта ',IFNULL(CNAME,'NULL'), ' c: ', IFNULL(SCNAME, 'NULL'), ' на ', IFNULL(PAR_SHORTNAME,'NULL'), ' Индекс: ', POSTALCODE));
                      UPDATE cities c set c.kodtst = (SELECT s.kod_t_st FROM socrbase s WHERE s.scname = PAR_SHORTNAME AND s.level = PAR_AOLEVEL) WHERE c.id = Cid;
                      set RET = 1;
                    END;
                  END IF;
                END;
              END IF;
           END WHILE;
            IF(done = 1) THEN 
              BEGIN 
                INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) 
                    VALUES (4 ,POSTALCODE , 6 ,CONCAT('В базе ФИАС не найден населенный пункт с названием: ', IFNULL(CNAME,'NULL'), ' есть только: ', IFNULL(PAR_OFFNAME, 'NULL'), ' Индекс: ', POSTALCODE));
                -- UPDATE cities c1 set AOGUID = 0 WHERE c1.id = Cid;
              END; 
            END IF;
         END; 
      CLOSE Parents;
    END;
  END IF;
END;

