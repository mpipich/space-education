create
    definer = root@`%` function get_city(region varchar(255), city varchar(255), city_1 varchar(255)) returns varchar(255)
BEGIN
    IF(IFNULL(city, '') = '' AND IFNULL(city_1,'') = '') THEN
      BEGIN
          RETURN lcfirst(del_many_space(region));
        END;
      END IF;

    RETURN lcfirst(del_many_space(city));
  END;

