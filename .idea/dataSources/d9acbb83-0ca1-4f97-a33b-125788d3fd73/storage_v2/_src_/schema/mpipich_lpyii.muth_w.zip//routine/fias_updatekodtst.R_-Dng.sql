create
    definer = root@`%` procedure fias_updatekodtst()
BEGIN 
DECLARE REGION, POSTALCODE integer;
/* переменная hadler - a*/
DECLARE done integer default 0;
DECLARE BankCursor Cursor for 
/* Селект на выборку данных которые расходятся со справочником почты России */
  SELECT o.`index`,r.id
    FROM operationaddress o 
    INNER JOIN cities c ON o.cityId = c.id 
    INNER JOIN regions r ON c.region = r.id 
    WHERE o.type NOT IN(3,4,17) AND c.AOGUID IS NULL;

/*HANDLER назначение, которого поясним чуть ниже*/
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

Open BankCursor;
WHILE done = 0 DO 
  FETCH BankCursor INTO POSTALCODE, REGION;
  CALL fias_getCityByIndex(POSTALCODE, REGION);
END WHILE;
CLOSE BankCursor;
END;

