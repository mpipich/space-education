create
    definer = root@`%` function compare_city(c1 varchar(255), c2 varchar(255)) returns int
BEGIN
    DECLARE tCity1, tCity2 varchar(255);
    DECLARE levenstain int(11);
    set tCity1 := UPPER(IFNULL(c1, ''));
    set tCity1 := REPLACE(tCity1, '-','');
    set tCity1 := REPLACE(tCity1, ' ','');

    set tCity2 := UPPER(IFNULL(c2, ''));
    set tCity2 := REPLACE(tCity2, '-','');
    set tCity2 := REPLACE(tCity2, ' ','');

    IF (IFNULL(tCity1,'') = IFNULL(tCity2,'')) THEN 
      BEGIN 
        RETURN 3; 
      END; 
    END IF;

    set levenstain:= levenshtein(tCity1, tCity2);

    IF levenstain < 3 THEN
      BEGIN
        RETURN 1;
        END;
      END IF;

    IF ((LOCATE(tCity1,tCity2,1) > 0) AND (tCity1 != '')) THEN
      BEGIN 
        RETURN 2;
        END;
      END IF;

    IF ((LOCATE(tCity2,tCity1,1) > 0) AND (tCity2 != '')) THEN
      BEGIN 
        RETURN 4;
        END;
      END IF;

    RETURN 0;
  END;

