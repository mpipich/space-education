create definer = root@`%` trigger TBU_pindx
    before UPDATE
    on pindx
    for each row
BEGIN
  set 
    NEW.N_REGION = get_region(NEW.REGION, NEW.AUTONOM),
    NEW.N_CITY = get_city(NEW.REGION, NEW.CITY, CASE WHEN (NEW.CITY_1 = NEW.CITY AND NEW.CITY_1 != '') THEN '' ELSE NEW.CITY_1 END),
    NEW.N_DISTRICT = get_district(NEW.AREA),
    NEW.N_CITY1 = del_many_space(CASE WHEN (NEW.CITY_1 = NEW.CITY AND NEW.CITY_1 != '') THEN '' ELSE NEW.CITY_1 END);
END;

