create
    definer = root@`%` function del_many_space(c varchar(255)) returns varchar(255)
BEGIN
    DECLARE tC varchar(255);
    set tC:= IFNULL(c,'');
    IF LOCATE('  ', tC) THEN 
      BEGIN 
        set tC:= REPLACE(tC, '  ',' '); 
      END;
    END IF;
    IF LOCATE('   ', tC) THEN 
      BEGIN 
        set tC:= REPLACE(tC, '   ',' '); 
      END;
    END IF; 

    RETURN mpipich_lpyii.lcfirst(tC);
  END;

