create
    definer = root@`%` procedure update_cities()
Begin 
/* переменные куда мы извлекаем данные */
DECLARE vRegionId integer;
DECLARE vAUTONOM VARCHAR(255);
DECLARE vAREA VARCHAR(255);
DECLARE vCITY VARCHAR(255);
DECLARE vCITY_1 VARCHAR(255);

DECLARE oINDEX integer; 
DECLARE oOPSNAME VARCHAR(255);
DECLARE oOPSTYPE VARCHAR(255);
DECLARE oOPSSUBM integer; 
DECLARE oREGION VARCHAR(255);
DECLARE oAUTONOM VARCHAR(255);
DECLARE oAREA VARCHAR(255); 
DECLARE oCITY VARCHAR(255);  
DECLARE oCITY_1 VARCHAR(255); 
DECLARE oACTDATE VARCHAR(255); 
DECLARE oINDEXOLD VARCHAR(255);

/* переменная hadler - a*/
DECLARE done integer default 0;
DECLARE id_update integer DEFAULT UNIX_TIMESTAMP(); 
/* Объявление курсора*/
DECLARE BankCursor Cursor for 
/* Селект на выборку данных которые расходятся со справочником почты России */
SELECT n.AREA, n.CITY, n.CITY_1, r.id FROM (
SELECT p.REGION, p.AREA, p.CITY, p.CITY_1 FROM (
  SELECT 
    c.id AS cid,
    c.district AS cdistrict,
    c.region AS cregion,
    CASE WHEN c.parentcityid IS NULL THEN c.name ELSE c1.name END AS cname,
    c.parentcityid,
    c.ready,
    c.kodtst, 
    IFNULL(d.name, '') AS dname,
    IFNULL(r.name,'') AS rname,
    IFNULL(r.ofname,'') AS rofname,
    CASE WHEN c.parentcityid IS NULL THEN '' ELSE c.name END AS cname_1 
  FROM cities c
    LEFT JOIN districts d ON c.district = d.id
    LEFT JOIN regions r ON c.region = r.id
    LEFT JOIN cities c1 ON c.parentcityid = c1.id
) t 
  RIGHT JOIN (
    SELECT 
      N_REGION AS REGION, 
      N_CITY AS CITY,
      N_DISTRICT AS AREA,
      N_CITY1 AS CITY_1
    FROM pindx p
    GROUP BY 
    N_REGION, 
    N_CITY, 
    N_DISTRICT, 
    N_CITY1
  ) p
  ON t.rofname = p.REGION
  AND t.dname = p.AREA
  AND t.cname = p.CITY
  AND t.cname_1 = p.CITY_1
  WHERE t.cid IS NULL ) n
  LEFT JOIN regions r ON n.REGION = r.ofname
  WHERE r.id IS NOT NULL;

/*HANDLER назначение, которого поясним чуть ниже*/
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

/* запуск процедуры */
INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 1 ,'START' );

INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log )
(
  SELECT 1, id_update, 14,
    CONCAT('Не хватает региона: ', get_region(p.REGION, p.AUTONOM)) AS REGION
  FROM pindx p
    LEFT JOIN regions r ON r.ofname = get_region(p.REGION, p.AUTONOM)
    WHERE r.id IS NULL
  GROUP BY get_region(p.REGION, p.AUTONOM) ORDER BY NULL
); 
   
/* открытие курсора */
/* Заполнение недостающих районов из справочника */
INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 2 ,'Заполнение недостающих районов из справочника START' );
INSERT INTO districts (name, region)
  SELECT 
    n.AREA,
    r.id
  FROM (
         SELECT
           p.*,
           t.*
         FROM (
                SELECT
                  get_region(p.REGION, p.AUTONOM) AS REGION,
                  get_district(p.AREA) AS AREA
                FROM pindx p
                WHERE p.AREA != ''
                GROUP BY get_region(p.REGION, p.AUTONOM), get_district(p.AREA)
              ) p
 
           LEFT JOIN (
                       SELECT
                         d.id AS DID,
                         d.name,
                         d.region AS dREGION,
                         r.ofname AS rname
                       FROM districts d
                         LEFT JOIN regions r ON d.region = r.id
                     ) t
 
             ON t.rname = p.REGION
             AND t.name = p.AREA
         WHERE t.DID IS NULL
       ) n
    LEFT JOIN regions r
      ON r.ofname = n.REGION
  WHERE r.id IS NOT NULL;
INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 3 ,'Заполнение недостающих районов из справочника END' );
INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 4 ,'Пометка коррекнтых данных START' );
/* Данные которые совпадают со правочником надо пометить чтобы не использовать их в будущем*/
UPDATE cities s SET s.ready = 0;
UPDATE cities cs INNER JOIN
(
SELECT t.cid FROM (
  SELECT 
    c.id AS cid,
    c.district AS cdistrict,
    c.region AS cregion,
    CASE WHEN c.parentcityid IS NULL THEN c.name ELSE c1.name END AS cname,
    c.parentcityid,
    c.ready,
    c.kodtst,
    IFNULL(d.name, '') AS dname,
    IFNULL(r.name,'') AS rname,
    IFNULL(r.ofname,'') AS rofname,
    CASE WHEN c.parentcityid IS NULL THEN '' ELSE c.name END AS cname_1 
  FROM cities c
    LEFT JOIN districts d ON c.district = d.id
    LEFT JOIN regions r ON c.region = r.id
    LEFT JOIN cities c1 ON c.parentcityid = c1.id
) t 
  RIGHT JOIN (
   SELECT 
      N_REGION AS REGION, 
      N_CITY AS CITY,
      N_DISTRICT AS AREA,
      N_CITY1 AS CITY_1
    FROM pindx p
    GROUP BY 
    N_REGION, 
    N_CITY, 
    N_DISTRICT, 
    N_CITY1 ORDER BY NULL
  ) p
  ON t.rofname = p.REGION
  AND t.dname = p.AREA
  AND t.cname = p.CITY
  AND t.cname_1 = p.CITY_1
 
  WHERE t.cid IS NOT NULL) rt ON cs.id = rt.cid
  SET cs.ready = 1;
INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 5 ,'Пометка коррекнтых данных END' );
Open BankCursor;
/* извлекаем данные */
WHILE done = 0 DO 
  FETCH BankCursor INTO vAREA,vCITY,vCITY_1,vRegionId;
  /* переменная в которую ляжет идентификатор населенного пункта */
  set @cityIdent = 0;
  /* поиск населенного пункта без учета района, предполагается 
  что населенный пункт либо выбыл из района либо наоборот вошел 
  в район или стал подчиненным какому-то другому НП
  */
  -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 13 ,CONCAT('Поикс населенного пункта без учера района ', ' ', vCITY, ' ', vCITY_1 ) );
  set @cntCityes:=0;
  set @cntCityes:= (
    SELECT COUNT(c.id)
      FROM cities c 
      LEFT JOIN cities c1 ON c.parentcityid = c1.id
      WHERE c.region = vRegionId 
      AND c.name = CASE vCITY_1 WHEN '' THEN vCITY ELSE vCITY_1 END
      AND c.ready != 1 
  );

  IF (@cntCityes < 2) THEN BEGIN

      set @cityIdent:= (SELECT c.id
          FROM cities c 
          LEFT JOIN cities c1 ON c.parentcityid = c1.id
          WHERE c.region = vRegionId 
          AND c.name = CASE vCITY_1 WHEN '' THEN vCITY ELSE vCITY_1 END
          AND c.ready != 1 ORDER BY c1.name LIMIT 1);
    
      IF (
        @cityIdent != 0 
      ) THEN
        /* если населенный пункт есть, то проверяем принадлежность его к району */
      BEGIN
        /* если район есть то переопределяем его*/
        IF (vAREA != '') THEN 
          BEGIN
            INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 6 , CONCAT('Обновление района у существующего населенного пункта') );
            UPDATE cities cD 
            SET cD.district = (
              SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA
            ), cD.AOGUID = null
            WHERE cD.id = @cityIdent ;
          END;
          /* если района у населенного пункта нету, то обнуляем его */
          ELSE
          BEGIN
            INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 7 ,CONCAT('Зануление района у существующего населенного пункта ', @cityIdent, ' ', vCITY, ' ', vCITY_1 ) );
            UPDATE cities cD 
            SET cD.district = 0, cD.AOGUID = null
            WHERE cD.id = @cityIdent ;
          END;
        END IF;
        IF (vCITY_1 = '') THEN
          INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 8 ,CONCAT('Зануление родителя у существующего населенного пункта ', @cityIdent, ' ', vCITY, ' ', vCITY_1 ) );
          BEGIN
            UPDATE cities cD_1 set cD_1.parentcityid = NULL, cD_1.AOGUID = NULL WHERE cD_1.id = @cityIdent;
          END;
          /* если населенный пункт стал подченем другому то надо его добавить */
          ELSE 
          BEGIN
            /* идентификатор родительского населенного пункта */
            SET @parentCityIdent = 0;
            /* поиск родительского населенного пункта */
            SET @parentCityIdent := (
              SELECT cP.id 
              FROM cities cP
                LEFT JOIN districts CD1 ON CD1.id = cP.district 
              WHERE cP.name = vCITY 
              AND cP.region = vRegionId
              AND cP.parentcityid IS NULL
              AND IFNULL(CD1.name, '') = vAREA
              ORDER BY cP.id LIMIT 1
            );
            /* Если родительский населенный пункт найден то прописываем его подчененнопу пункту если его нету, 
            то он скорее всего добавится ниже по коду и надо будет перезапустить процедуру еще разок*/
            IF (
              @parentCityIdent != 0
            ) THEN 
              BEGIN 
                INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 9 ,'Добавление родителя у существующего населенного пункта' );
                UPDATE cities cD_2 set cD_2.parentcityid = @parentCityIdent, cD_2.AOGUID = NULL WHERE cD_2.id = @cityIdent;    
              END;
              ELSE
              BEGIN
                INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 31 ,'Создание родителя для существующего населенного пункта' );
                INSERT IGNORE INTO cities (district, region, name, parentcityid, ready, kodtst) VALUE 
                (
                  IFNULL((SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA),0),
                  vRegionId,
                  lcfirst(vCITY),
                  NULL,
                  0,
                  0
                );
                INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 91 ,'Добавление родителя у существующего населенного пункта' );
                UPDATE cities cD_2 set cD_2.parentcityid = @parentCityIdent, cD_2.AOGUID = NULL WHERE cD_2.id = LAST_INSERT_ID();
              END;
            END IF;
          END;
        END IF;
      END;
      /*Если населенный пункт не в каком виде не найден*/
      ELSE 
        BEGIN 
          SET @parentCityIdentIns = NULL;
          IF (vCITY_1 = '') THEN
            /* Если этот населенный пункт не является подчиненным, то просто инсервим его */
            BEGIN
              INSERT IGNORE INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) 
              VALUES ( 1 ,id_update , 10 ,CONCAT('Создание нового населенного пункта ', concat(upper(LEFT (LOWER(vCITY), 1)), substr(LOWER(vCITY), 2))) );
              INSERT IGNORE INTO cities (district, region, name, parentcityid, ready, kodtst) VALUE 
              (
                IFNULL((SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA ORDER BY dD.id LIMIT 1),0),
                vRegionId,
                lcfirst(vCITY),
                NULL,
                0,
                0
              );
            END;
            ELSE
            /*Если этот населенный пункт является подчиненным, то вначале ищем родительский населенный пункт, а потом инсертим */
            BEGIN
              SET @parentCityIdentIns := (
              SELECT cPi.id 
              FROM cities cPi
                LEFT JOIN districts CD1 ON CD1.id = cPi.district 
              WHERE cPi.name = vCITY 
              AND cPi.region = vRegionId
              AND cPi.parentcityid IS NULL
              AND IFNULL(CD1.name, '') = vAREA);
              IF (
                @parentCityIdentIns != 0
              ) THEN 
                BEGIN
                   /*Если родительский населенный пункт найден то прежде чем инсертить необходимо проверить нет ли такого же населенного пункта с таким же регионом и районом
                    Дело в том, что есть населенные пункты у которых все одинаково, а только отилчается родительский населенный пункт, а в базе иникальный ограничитель на регион, название и район
                    отключать его нельзя, поэтому это оставляется на ручное разруливание. и просто пишется предупреждение в лог
                  */
                    IF NOT EXISTS (
                      SELECT * FROM cities 
                        WHERE district = IFNULL((SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA),0)
                        AND region = vRegionId
                        AND name = lcfirst(vCITY_1)
                      ) THEN 
                      BEGIN 
                       INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 11 ,CONCAT('Создание нового населенного пункта и добавление ему родителя ', concat(upper(LEFT (LOWER(vCITY_1), 1)), substr(LOWER(vCITY_1), 2)),' родитель ', @parentCityIdentIns) );
                       INSERT INTO cities (district, region, name, parentcityid, ready, kodtst) VALUE 
                        (
                          IFNULL((SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA),0),
                          vRegionId,
                          lcfirst(vCITY_1),
                          @parentCityIdentIns,
                          0,
                          0
                        );
                      END; 
                      ELSE
                      BEGIN
                        INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 23 ,CONCAT('ВНИМАНИЕ! Неудалось создать населенный пункт', lcfirst(vCITY_1),' в районе c ID:  ', IFNULL((SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA),0), ' и регионе: ', vRegionId, ' родитель: ', @parentCityIdentIns, ' из за того что НП в таком регионе и районе уже есть, родитель не учитывается') );
                      END;
                    END IF;
    
                END;
                  ELSE
                    BEGIN
                      SET @parentCityIdentNoDistr := 0;
                      SET @parentCityIdentNoDistr := (
                          SELECT cPi.id 
                          FROM cities cPi
                            LEFT JOIN districts CD1 ON CD1.id = cPi.district 
                          WHERE cPi.name = vCITY 
                          AND cPi.region = vRegionId
                          AND cPi.parentcityid IS NULL
                           AND cPi.ready = 0
                      );
    
                      IF(@parentCityIdentNoDistr = 0) THEN
                        BEGIN
        
                          INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 16 ,CONCAT('Создание нового родительского населенного пункта'));
                          INSERT INTO cities (district, region, name, ready, kodtst ) VALUE
                          (
                            0,
                            vRegionId,
                            concat(upper(LEFT (LOWER(vCITY), 1)), substr(LOWER(vCITY), 2)),
                            0,
                            0
                          );
                          SET @parentCityIdentIns := LAST_INSERT_ID();
                        END;
                        ELSE
                          BEGIN
                            IF(vAREA = '') THEN 
                            BEGIN
                              INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) 
                              VALUES ( 1 ,id_update , 21 ,CONCAT('Зануление района у существующего родительского населенного пункта ',  IFNULL(@parentCityIdentNoDistr,''), ' ', IFNULL(vCITY,''), ' ', IFNULL(vCITY_1,'') ) );
                              UPDATE IGNORE cities cD 
                              SET cD.district = 0
                              WHERE cD.id = @parentCityIdentNoDistr ;
                            END;
                            ELSE 
                            BEGIN 
                              INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 22 , CONCAT('Обновление района у существующего родительского населенного пункта') );
                              UPDATE cities cD 
                              SET cD.district = (
                                SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA
                              ), cD.AOGUID = NULL
                              WHERE cD.id = @parentCityIdentNoDistr ;
                            END; 
                            END IF;
                            SET @parentCityIdentIns := @parentCityIdentNoDistr;
                          END;
                        END IF;
                        INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 25 , CONCAT('Создание нового населенного пункта') );
                        INSERT IGNORE INTO cities (district, region, name, parentcityid, ready, kodtst) VALUE 
                          (
                            IFNULL((SELECT dD.id FROM districts dD WHERE dD.region = vRegionId AND dD.name = vAREA),0),
                            vRegionId,
                            concat(upper(LEFT (LOWER(vCITY_1), 1)), substr(LOWER(vCITY_1), 2)),
                            @parentCityIdentIns,
                            0,
                            0
                          );
                    END;
              END IF;
            END;
          END IF;
        END;
      END IF;
  END;
  ELSE
  BEGIN
    INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 24 ,CONCAT('ВНИМАНИЕ! по населенному пункту', CASE vCITY_1 WHEN '' THEN vCITY ELSE vCITY_1 END, ' в регионе: ', vRegionId, ' есть больше двух совпадений, которые все не подходят, требуется ручное вмешательство') );
  END;
  END IF;

END WHILE;
/*закрытие курсора */
Close BankCursor; 

INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 20 ,'Обновление справочника типов ОПС' );
INSERT INTO opstypev2 (abbr)
SELECT DISTINCT(t1.OPSTYPE) AS abbr FROM pindx AS t1 
LEFT JOIN opstypev2 v ON opstype = v.abbr WHERE v.abbr IS NULL;

INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 1 ,id_update , 12 ,'END' );
END;

