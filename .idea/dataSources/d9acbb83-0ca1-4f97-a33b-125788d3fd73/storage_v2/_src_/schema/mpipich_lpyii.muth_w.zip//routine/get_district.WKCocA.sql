create
    definer = root@`%` function get_district(district varchar(255)) returns varchar(255)
BEGIN
    DECLARE nD varchar(255);
    set nD := IFNULL(district,'');
    IF((LOCATE('УЛУС',district))) THEN
      BEGIN
        set nD:= REPLACE(district,'УЛУС','РАЙОН');
      END;
      END IF;

    RETURN concat(upper(LEFT (LOWER(nD), 1)), substr(LOWER(nD), 2));
  END;

