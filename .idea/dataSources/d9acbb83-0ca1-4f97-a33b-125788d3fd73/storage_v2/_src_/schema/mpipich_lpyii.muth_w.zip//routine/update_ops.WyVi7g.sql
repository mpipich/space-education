create
    definer = root@`%` procedure update_ops()
Begin 
/* переменные куда мы извлекаем данные */
DECLARE oINDEX integer; 
DECLARE oOPSNAME VARCHAR(255);
DECLARE oOPSTYPE integer;
DECLARE oOPSSUBM integer; 
DECLARE oREGION VARCHAR(255);
DECLARE oAUTONOM VARCHAR(255);
DECLARE oAREA VARCHAR(255); 
DECLARE oCITY VARCHAR(255);  
DECLARE oCITY_1 VARCHAR(255); 
DECLARE oACTDATE VARCHAR(255); 
DECLARE oINDEXOLD VARCHAR(255);
DECLARE oN_REGION VARCHAR(255);
DECLARE oN_CITY varchar(255);
DECLARE oN_DISTRICT varchar(255);
DECLARE oN_CITY1 varchar(255);

DECLARE oOP_INDEX integer;
DECLARE oOP_NAME VARCHAR(255);
DECLARE oOP_CITYID integer;
DECLARE oOP_TYPE integer;
DECLARE oOP_OPSSUBM integer;
DECLARE oOP_CREG integer;
DECLARE oOP_AOGUID varchar(255) DEFAULT 0;

/* переменная hadler - a*/
DECLARE done integer default 0;
DECLARE id_update integer DEFAULT UNIX_TIMESTAMP(); 
/* Объявление курсора*/

/*HANDLER назначение, которого поясним чуть ниже*/

/* Объявление курсора для инсерта ОПС*/
DECLARE ops Cursor for
  SELECT
  x.`INDEX`,
  lcfirst(x.OPSNAME) AS OPSNAME,
  v2.id AS OPSTYPE,
  x.OPSSUBM,
  x.REGION,
  x.AUTONOM,
  x.AREA,
  x.CITY,
  x.CITY_1,
  x.ACTDATE,
  x.INDEXOLD,

  o.`index` AS OP_INDEX,
  lcfirst(o.name) AS OP_NAME,
  o.cityId AS OP_CITYID,
  o.type AS OP_TYPE,
  o.opssubm AS OP_OPSSUBM,
  c.region AS OP_CREG,
  c.AOGUID AS OP_AOGUID,
  x.N_REGION AS N_REGION,
  x.N_CITY AS N_CITY,
  x.N_DISTRICT AS N_DISTRICT,
  x.N_CITY1 AS N_CITY1
FROM pindx x
  LEFT JOIN opstypev2 v2  ON v2.abbr = x.OPSTYPE
  LEFT JOIN operationaddress o ON o.`index` = x.`INDEX`
  LEFT JOIN cities c ON o.cityId = c.id;

DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

/*HANDLER назначение, которого поясним чуть ниже*/

/* запуск процедуры */
INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 1 ,'START' );

Open ops;
SET @done:= 0;
WHILE done = 0 DO 
  FETCH ops INTO oINDEX, oOPSNAME, oOPSTYPE, oOPSSUBM, oREGION, oAUTONOM, oAREA, oCITY, oCITY_1, oACTDATE, oINDEXOLD, oOP_INDEX, oOP_NAME, oOP_CITYID, oOP_TYPE, oOP_OPSSUBM, oOP_CREG, oOP_AOGUID, oN_REGION, oN_CITY, oN_DISTRICT, oN_CITY1;
    
    SET @sityIdent:= 0;
    -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 9 ,CONCAT('Для индекса ',oINDEX, ' выборка населенного пункта START'));
    SET @sityIdent:= (
      SELECT c.id
        FROM cities c 
        LEFT JOIN cities c1 ON c.parentcityid = c1.id
        LEFT JOIN districts d1 ON d1.id = c.district
        LEFT JOIN regions r ON r.id = c.region
        WHERE UPPER (r.ofname) = UPPER(oN_REGION)
        AND get_district(IFNULL(d1.name,'')) = oN_DISTRICT
        AND oN_CITY = CASE WHEN c.parentcityid IS NULL THEN c.name ELSE c1.name END 
        AND oN_CITY1 = CASE WHEN c.parentcityid IS NULL THEN '' ELSE c.name END
    );
    -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 10 ,CONCAT('Для индекса ',oINDEX, ' выборка населенного пункта END'));
    IF (@sityIdent = 0 OR IFNULL(@sityIdent, 0) = 0) THEN 
      BEGIN 
        INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 2 ,CONCAT('Для индекса ',oINDEX, ' не найден населенный пункт Рег:', IFNULL(oREGION,''), ', ', ' р-н: ', IFNULL(oAREA,''), ', г.: ', IFNULL(oCITY,''), ' г1: ', IFNULL(oCITY_1,'')));
     END;
     ELSE
      BEGIN 
      IF IFNULL(oOP_INDEX, 101) = 101
        THEN
          BEGIN
          INSERT INTO operationaddress
            (
              `index`
             ,name
             ,cityId
             ,type
             ,SummRating
             ,votes
             ,last_modified
             ,opssubm
            )
            VALUES
            (
              oINDEX -- index - INT(11) NOT NULL
             ,oOPSNAME -- name - VARCHAR(255) NOT NULL
             ,@sityIdent -- cityId - INT(11) NOT NULL
             ,oOPSTYPE -- type - INT(11) NOT NULL
             ,0 -- SummRating - INT(11) NOT NULL
             ,0 -- votes - INT(11) NOT NULL
             ,NOW() -- last_modified - DATETIME NOT NULL
             ,oOPSSUBM
            );
      
            INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 3 ,CONCAT('Добавлен новый почтовый индекс: ', oINDEX, ' с названием: ', oOPSNAME));
            
        END;
        ELSE
          BEGIN
            IF oOPSNAME != oOP_NAME THEN
              BEGIN
                  UPDATE operationaddress SET name = oOPSNAME WHERE `index` = oOP_INDEX;
                  INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 4 ,CONCAT('У индекса: ', oINDEX, ' изменено название c ', IFNULL(oOP_NAME,'NULL'), ' на ', IFNULL(oOPSNAME,'NULL')));
              END;
            END IF;

            IF oOPSTYPE != oOP_TYPE THEN
              BEGIN
                UPDATE operationaddress SET type = oOPSTYPE WHERE `index` = oOP_INDEX;
                INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 5 ,CONCAT('У индекса: ', oINDEX, ' изменен тип с ', IFNULL(oOP_TYPE,''), ' на ', IFNULL(oOPSTYPE,'')));
              END;
            END IF;

            IF IFNULL(oOPSSUBM, '') != IFNULL(oOP_OPSSUBM, '') THEN
              BEGIN
                UPDATE operationaddress SET opssubm = oOPSSUBM WHERE `index` = oOP_INDEX;
                INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 6 ,CONCAT('У индекса: ', oINDEX, ' изменен вышестоящий индекс с ', IFNULL(oOP_OPSSUBM,'NULL'), ' на ',  IFNULL(oOPSSUBM,'NULL')));
              END;
            END IF;
            
            IF(@sityIdent != oOP_CITYID) THEN
              BEGIN
                IF NOT EXISTS (
                    SELECT 
                      t_.id AS t_ID,
                      r_.id AS r_ID,
                      t_.name AS t_NAME,
                      get_district(d_.name) AS d_NAME,
                      c_.name AS c_NAME,
                      p.*
                      FROM cities AS t_
                      LEFT JOIN regions AS r_ ON t_.region = r_.id
                      LEFT JOIN districts AS d_ ON IFNULL(t_.district, 0) = d_.id
                      LEFT JOIN cities c_ ON t_.parentcityid = c_.id
                      LEFT JOIN 
                      (
                          SELECT 
                            t1_.id AS t1_ID,
                            r1_.id AS r1_ID,
                            t1_.name AS t1_NAME,
                            get_district(d1_.name) AS d1_NAME,
                            c1_.name AS c1_NAME 
                            FROM cities AS t1_
                            LEFT JOIN regions AS r1_ ON t1_.region = r1_.id
                            LEFT JOIN districts AS d1_ ON IFNULL(t1_.district, 0) = d1_.id
                            LEFT JOIN cities c1_ ON t1_.parentcityid = c1_.id
                            WHERE t1_.id = @sityIdent
                      ) p
                  
                      ON p.r1_ID = t_.region
                      WHERE t_.id = oOP_CITYID
                      AND
                      compare_city(t_.name, p.t1_NAME) != 0
                      AND
                      compare_city(get_district(IFNULL(d_.name,'')), get_district(IFNULL(p.d1_NAME,''))) != 0
                      AND
                      compare_city(IFNULL(c_.name,''), IFNULL(p.c1_NAME,'')) != 0
                ) THEN
                BEGIN
                  INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 11 ,CONCAT('Для индекса ',oINDEX, ' Изменение населенного пункта'));
                  UPDATE operationaddress SET cityId = @sityIdent WHERE `index` = oOP_INDEX;
                  INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 7 ,CONCAT('У индекса: ', oINDEX, ' изменен населенный пункт с ', oOP_CITYID, ' на ',  IFNULL(oCITY,'NULL')));
                END;
                END IF;

              END;
            END IF;

          END;
        END IF;
        
        /*IF(oOPSTYPE != 3 AND oOPSTYPE != 4 AND oOPSTYPE != 17 AND IFNULL(oOP_AOGUID, '') = '') THEN
          CALL fias_getCityByIndex(oOP_INDEX, oOP_CREG);
        END IF;*/

      END;
    END IF;

    
  
END WHILE;
/*закрытие курсора */
Close ops; 


INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 2 ,id_update , 8 ,'END' );
END;

