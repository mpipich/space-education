create
    definer = root@`%` procedure fias_updatecityname()
BEGIN 
DECLARE cID, cDISTRICT, cREGION, cPARENTCITYID, cREADY, cKODTST integer;
DECLARE cNAME, cAOGUID, cOFNAME varchar(255);
/* переменная hadler - a*/
DECLARE id_update integer DEFAULT UNIX_TIMESTAMP(); 
DECLARE done integer default 0;
DECLARE BankCursor Cursor for 
/* Селект на выборку данных которые расходятся со справочником почты России */
    SELECT c.id, c.district, c.region, c.name, c.parentcityid, c.ready, c.kodtst, c.AOGUID
    -- (SELECT a.OFFNAME FROM addrobjectpar a WHERE a.REGIONCODE = c.region AND a.AOGUID = c.AOGUID ORDER BY a.LIVESTATUS DESC LIMIT 1) AS OFNAME
    FROM cities c WHERE c.AOGUID IS NOT NULL;

/*HANDLER назначение, которого поясним чуть ниже*/
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 1 ,'START' );

Open BankCursor;
WHILE done = 0 DO 
  FETCH BankCursor INTO cID,cDISTRICT,cREGION,cNAME,cPARENTCITYID,cREADY,cKODTST,cAOGUID;
  set @cityIdent:= 0;
  set @cityName:='';
  SELECT a.OFFNAME INTO cOFNAME FROM addrobjectpar a WHERE a.REGIONCODE = cREGION AND a.AOGUID = cAOGUID ORDER BY a.LIVESTATUS DESC LIMIT 1;
  IF(cOFNAME != cNAME) THEN 
    BEGIN
      INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 2 ,CONCAT('Населенный пункт, который не совпадает с ФИАС. В базе: ', cNAME, ' в ФИАС: ', cOFNAME) );
      
      -- SELECT c.id, c.name INTO @cityIdent, @cityName FROM cities c WHERE c.district = cDISTRICT AND c.region = cREGION AND c.name = cOFNAME;
      
      SET @cityIdent:= (SELECT c.id FROM cities c WHERE c.district = cDISTRICT AND c.region = cREGION AND c.name = cOFNAME);
      SET @cityName:= (SELECT c.name FROM cities c WHERE c.district = cDISTRICT AND c.region = cREGION AND c.name = cOFNAME);

      -- INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 2 ,CONCAT('ID: ', @cityIdent) );
      IF(@cityIdent != 0 OR IFNULL(@cityIdent, 0 ) != 0) THEN 
        BEGIN
          INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 3 ,CONCAT('Найден дублирующий населенный пункт: ', IFNULL(@cityName,'NULL'), ' нужный: ', cNAME, ' ID: ', @cityIdent) );
          set @cntchild:= 0;
          SELECT COUNT(id) INTO @cntchild FROM cities c WHERE c.parentcityid = @cityIdent;
          IF(@cntchild != 0) THEN 
            BEGIN
              INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 4 ,CONCAT('Обновление родителей с: ', IFNULL(@cityName,'NULL'), ' на: ', cNAME) );
              UPDATE cities c set c.parentcityid = cID WHERE c.parentcityid = @cityIdent;
            END; 
          END IF;

          set @cntoperAddr:= 0;
          set @cntoperAddr:=(SELECT COUNT(o.`index`) FROM operationaddress o WHERE o.cityId = @cityIdent);
          IF(@cntoperAddr != 0 OR IFNULL(@cntoperAddr, 0 ) != 0) THEN 
            BEGIN
              INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 5 ,CONCAT('Обновление населенных пунктов ОПС с: ', IFNULL(@cityName,'NULL'), ' на: ', cNAME) );
              UPDATE operationaddress o set o.cityId = cID WHERE o.cityId = @cityIdent;
            END;
          END IF;
          INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 6 ,CONCAT('Удаление ', IFNULL(@cityName,'NULL')) );
          DELETE FROM cities WHERE id = @cityIdent;
          INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 7 ,CONCAT('Обновление названия с ', IFNULL(cNAME,'NULL'), ' на ', cOFNAME) );
          UPDATE cities c set c.name = cOFNAME WHERE c.id = cID;
        END;
        ELSE 
          BEGIN 
            INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 8 ,CONCAT('Обновление названия с ', IFNULL(cNAME,'NULL'), ' на ', cOFNAME) );
            UPDATE cities c set c.name = cOFNAME WHERE c.id = cID;
          END; 
      END IF;
    END;
    ELSE 
      BEGIN
        INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 9 ,CONCAT('Обновление названия с ', IFNULL(cNAME,'NULL'), ' на ', cOFNAME) );
        UPDATE cities c set c.name = cOFNAME WHERE c.id = cID; 
      END;
  END IF;
END WHILE;
CLOSE BankCursor;
  INSERT INTO tmp_log ( id_procedure ,id_update ,id_action ,log ) VALUES ( 5 ,id_update , 10 ,'END' );
END;

